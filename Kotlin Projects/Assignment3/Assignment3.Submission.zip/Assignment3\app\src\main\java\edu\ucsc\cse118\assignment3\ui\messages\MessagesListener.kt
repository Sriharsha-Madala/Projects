package edu.ucsc.cse118.assignment3.ui

import edu.ucsc.cse118.assignment3.data.Messages

interface MessagesListener {
    fun onClick(message: Messages)
}